package pl.edu.pb.zadanie9;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ApiResponse {
    @SerializedName("num_found")
    private int num_found;

    @SerializedName("docs")
    private List<Book> data;

    // Getters...
    public List<Book> getData() {
        return data;
    }

    public static class Book {
        @SerializedName("title")
        private String tytul;
        @SerializedName("first_publish_year")
        private int year;
        @SerializedName("author_name")
        private String[] authors;
        @SerializedName("cover_i")
        private int id;

        public String getTitle(){ return tytul;}
        public int getPublishYear(){return year;}
        public String[] getAuthors(){return authors;}

        public String getLImageUrl(){
            return "https://covers.openlibrary.org/b/id/"+this.id+"-M.jpg";
        }
        public String getMImageUrl(){
            return "https://covers.openlibrary.org/b/id/"+this.id+"-M.jpg";
        }
        public String getSImageUrl(){
            return "https://covers.openlibrary.org/b/id/"+this.id+"-M.jpg";
        }

    }
}
