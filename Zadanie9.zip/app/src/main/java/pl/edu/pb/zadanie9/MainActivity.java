package pl.edu.pb.zadanie9;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

import java.util.List;

public class MainActivity extends AppCompatActivity implements ApiRequestTask.ApiRequestListener{

    private BookAdapter bookAdapter;
    private RecyclerView recyclerView;

    private EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.Search_field);

        searchEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                handleTextSubmission();
                return true;
            }
            return false;
        });

    }

    private void handleTextSubmission() {
        String enteredText = searchEditText.getText().toString();
        searchEditText.getText().clear(); // Wyczyść tekst w polu EditText

        new ApiRequestTask(this).execute(enteredText);

    }


    @Override
    public void onApiRequestSuccess(ApiResponse result) {
        List<ApiResponse.Book> bookList = result.getData();

        bookAdapter = new BookAdapter(this);
        bookAdapter.setBookList(bookList);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setAdapter(bookAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    public void onApiRequestFailure() {
        Alert alert = new Alert("Error", "Nie udało się wykonać zapytania");
        alert.Show(this);
    }
}