package pl.edu.pb.zadanie9;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("search.json")
    Call<ApiResponse> searchBook(@Query("q") String query, @Query("limit") int limit);
}
