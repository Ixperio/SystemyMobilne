package pl.edu.pb.zadanie9;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {

    private List<ApiResponse.Book> bookList;
    private Context context;

    public BookAdapter(Context context) {
        this.context = context;
    }

    public void setBookList(List<ApiResponse.Book> bookList) {
        this.bookList = bookList;
    }

    public List<ApiResponse.Book> getBookList(){
        return this.bookList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_book, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ApiResponse.Book book = bookList.get(position);

        // Ustawienie tytułu
        holder.titleTextView.setText(book.getTitle());
        String[] authors = book.getAuthors();

        //ustawienie autorów
        String authorText="";
        int val = 0;
        for(String author : authors){
            if(val < authors.length-1){
                authorText += author+", ";
            }else{
                authorText += author;
            }
            val++;
        }

        holder.authorsTextView.setText(authorText);

        // Ładowanie obrazu z internetu za pomocą Glide
        if (book.getMImageUrl() != null) {
            String imageUrl = book.getMImageUrl();
            Glide.with(context)
                    .load(imageUrl)
                    .into(holder.imageView);
        }
    }

    @Override
    public int getItemCount() {
        return bookList != null ? bookList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;
        public TextView titleTextView;
        public TextView authorsTextView;

        public ViewHolder(View view) {
            super(view);
            imageView = view.findViewById(R.id.imageView);
            titleTextView = view.findViewById(R.id.titleTextView);
            authorsTextView = view.findViewById(R.id.authorsTextView);
        }
    }
}