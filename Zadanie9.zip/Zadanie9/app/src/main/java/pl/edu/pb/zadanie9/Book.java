package pl.edu.pb.zadanie9;
import com.google.gson.annotations.SerializedName;

public class Book {
    @SerializedName("title")
    private String title;
    @SerializedName("author_name")
    private String[] authors;
    @SerializedName("cover_i")
    private String cover;
    @SerializedName("number_of_pages_median")
    private String numberOfPages;

    //gettery i settery

    public boolean setTitle(String val){
        this.title = val;
        return true;
    }
    public boolean setCover(String val){
        this.cover = val;
        return true;
    }
    public boolean setNumberOfPages(String val){
        this.numberOfPages = val;
        return true;
    }
    public boolean setAuthors(String[] val){
        this.authors = val;
        return true;
    }

    public String getTitle(){
        return this.title;
    }
    public String getCover(){
        return this.cover;
    }
    public String getNumberOfPages(){
        return this.numberOfPages;
    }
    public String[] getAuthors(){
        return this.authors;
    }
}
