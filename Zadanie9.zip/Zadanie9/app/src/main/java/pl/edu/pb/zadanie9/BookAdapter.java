package pl.edu.pb.zadanie9;

import android.util.Log;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter{

    private List<Book> books;

    public void onBindViewHolder(@NonNull BookHolder holder, int position){
        if(books != null){
            Book book = books.get(position);
            holder.bind(book);
        }else{
            Log.d("MainActivity", "No books");
        }
    }
    public void setBooks(List<Book> book){
        this.books = books;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
