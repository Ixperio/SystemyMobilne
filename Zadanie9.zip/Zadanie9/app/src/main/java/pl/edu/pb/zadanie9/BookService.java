package pl.edu.pb.zadanie9;

import retrofit2.http.Query;

public interface BookService {
    @GET("search.json")
    Call<BookContainer> findBooks(@Query("q") String query);
}
