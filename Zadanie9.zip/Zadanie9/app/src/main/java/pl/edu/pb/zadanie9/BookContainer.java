package pl.edu.pb.zadanie9;
import com.google.gson.annotations.SerializedName;

public class BookContainer {
    @SerializedName("docs")
    private Book[] bookList;

    //gettery i settery
    public Book[] getBooks(){
        return this.bookList;
    }
    public boolean setBooks(Book[] val){
        this.bookList = val;
        return true;
    }
}
