package pl.edu.pb.zadanie9;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BookContainer {
    @SerializedName("docs")
    private List<Book> bookList;

    //gettery i settery
    public List<Book> getBooks(){

        return this.bookList;
    }
    public boolean setBooks(List<Book> val){
        this.bookList = val;
        return true;
    }
}
