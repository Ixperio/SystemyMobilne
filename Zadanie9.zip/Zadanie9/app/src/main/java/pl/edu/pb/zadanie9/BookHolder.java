package pl.edu.pb.zadanie9;

import android.widget.TextView;

import com.squareup.picasso.Picasso;

private class BookHolder extends RecyclerView.ViewHolder {
    private static final String IMAGE_URL_BASE = "http://covers.openlibrary.orgibildr;
    private final TextView bookTitleTextView;
    private final TextView bookAuthorTextView;
    private final TextView number0fPagesTextView;
    private final ImageView bookCover;

    public BookHolder(Layoutlnflater inflater, ViewGroup parent) {
        super(inflater.inflate(R.layout.book_list_item, parent, attachToRoot:false));
        bookAuthorTextView = itemView.findViewById(R.id.book_author);
        bookAuthorTextView = itemView.findViewById(R.id.book_author);
        number0fPagesTextView = itemView.findViewByld(R.id.number_of_pages);
        bookCover = itemView.findViewById(R.id.img_cover);
    }

    public void bind(Book book) {
        if (book != null && checkNullOrEmpty(book.getTitle()) && book.getAuthors() != null) {
            bookTitleTextView.setText(book.getTitle());
            bookAuthorTextView.setText(TextUtils.join(", ", book.getAuthors()));
            number0fPagesTextView.setText(book.getNumberOfPages());
            if(book.getCover() != null){
                Picasso.with(itemView.getContext())
                        .load(IMAGE_URL_BASE + book.getCover() + "-S.jpg")
                        .placeholder(R.drawable.ic_book_black_24dp).into(bookCover);
            }else{
                bookCover.setImageResource(R.drawable.ic_book_black_24dp);
            }
        }
    }

}