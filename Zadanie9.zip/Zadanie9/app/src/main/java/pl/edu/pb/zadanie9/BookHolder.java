package pl.edu.pb.zadanie9;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.*;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

class BookHolder extends RecyclerView.ViewHolder {
    private static final String IMAGE_URL_BASE = "http://covers.openlibrary.orgibildr";
    private TextView bookTitleTextView;
    private TextView bookAuthorTextView;
    private TextView number0fPagesTextView;
    private ImageView bookCover;

    public BookHolder(LayoutInflater inflater, ViewGroup parent) {
        super(inflater.inflate(R.layout.book_list_item, parent));
        bookAuthorTextView = itemView.findViewById(R.id.book_author);
        bookAuthorTextView = itemView.findViewById(R.id.book_author);
        number0fPagesTextView = itemView.findViewById(R.id.number_of_pages);
        bookCover = itemView.findViewById(R.id.img_cover);
    }

    public void bind(Book book) {
        if (book != null && (book.getTitle() != "") && book.getAuthors() != null) {
            bookTitleTextView.setText(book.getTitle());
            bookAuthorTextView.setText(TextUtils.join(", ", book.getAuthors()));
            number0fPagesTextView.setText(book.getNumberOfPages());
            if(book.getCover() != null){
                Picasso.with(itemView.getContext())
                        .load(IMAGE_URL_BASE + book.getCover() + "-S.jpg")
                        .placeholder(R.drawable.book).into(bookCover);//rysuje standardowa okładkę
            }else{
                bookCover.setImageResource(R.drawable.book); //rysuje standardowa okładkę
            }
        }
    }

}